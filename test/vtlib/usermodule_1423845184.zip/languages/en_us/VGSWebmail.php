<?php

$languageStrings = array(
    'vgs_webmail_module'=>'VGS Webmail Module',
    'email_imap_settings'=>'IMAP Settings',
    'error_notice'=>'Something failed. Please double check your settings and try again.',
    'username'=>'Username',
    'password'=>'Password',
    'host'=>'IMAP Host',
    'port'=>'Port',
    'server-template'=>'Please choose a server from the list',
    'smtp_port'=>'SMTP Port',
    'smtp_server'=>'SMTP Port',
    'smtp_user'=>'SMTP User',
    'smtp_pass'=>'SMTP Pass',
    'displayname'=>'Display Name',
    'language'=>'Language',
    'vgs_webmail_settings'=>'Please insert your IMAP account settings and hit the save button.',
    'vgs_webmail_no_account'=>'No Account Is Setup Yet',
    'vgs_webmail_no_account_text'=>'Please set up an account to send, receive and keep your messages in order rigth in your CRM',
    'vgs_webmail_add_account_text'=>'Click here to set up you account',
    'autosaveattachments'=>'Auto save attachments in server?',
    
);
